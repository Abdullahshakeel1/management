import express from "express";
import dotenv from "dotenv";
import { connectDB } from "./connection/db_connection.js";
import cors from 'cors';
import bodyParser from "body-parser";
import personRoute from "./routes/personRoute.js";

dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());
app.use(bodyParser.json());

app.use('/person', personRoute);

connectDB().then(() => {
  app.listen(process.env.PORT, () => {
    console.log(`Server is running on port ${process.env.PORT}`);
  });
});
